function NCPdynamics(obj)
% to be done with the CDA case ???
  

end

