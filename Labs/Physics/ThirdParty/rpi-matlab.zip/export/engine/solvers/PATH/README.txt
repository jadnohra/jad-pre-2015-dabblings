The PATH solver files in this directory were all downloaded from 
http://pages.cs.wisc.edu/~ferris/path.html
It's possible that you may have to download different mex files from 
there in order to run in a different environment.  

