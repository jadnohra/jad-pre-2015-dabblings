
Sunday, 17 June, 2012
     So, I can't quite say for certain where I got this implementation of Lemke's algorithm.  
However, thanks to the interwebs, I believe I have discovered its origin: 

http://www.mathworks.de/matlabcentral/newsreader/view_original/22458

So, thank you Paul.  
Sincerely, 
 Jed

